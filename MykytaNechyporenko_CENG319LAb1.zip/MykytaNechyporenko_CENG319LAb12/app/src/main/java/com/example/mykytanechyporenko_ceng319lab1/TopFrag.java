package com.example.mykytanechyporenko_ceng319lab1;

import androidx.fragment.app.ListFragment;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.ListFragment;

import static java.lang.String.*;
public class TopFrag extends ListFragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view=inflater.inflate(R.layout.top,container,false);
        ArrayAdapter<String>adapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.ItemList));
        setListAdapter(adapter);
        return view;
    }



    @Override
    public void onListItemClick(ListView l, View v, int pos, long id){
        Intent intent=null;
                if(pos==0){
                    intent=new Intent(getContext(),AIActivity.class);
                    startActivity(intent);
                }
                if(pos==1){
                    intent=new Intent(getContext(),VRAcitivity.class);
                    startActivity(intent);
                }
    }

}
