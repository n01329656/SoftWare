package com.example.mykytanechyporenko_ceng319lab1;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class BottomFrag extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view=inflater.inflate(R.layout.fragment_bottom, container, false);
        return view;
    }


    public void display(String msg, TextView text){
        if(text.getText().toString().equals("")){
            text.setText(msg);
            text.append("\n");}
        else{  text.append(msg); text.append("\n");}
    }

}